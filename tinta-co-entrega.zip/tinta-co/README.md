# Tinta&Co — Web + CRM

Monorepo con dos aplicaciones **Next.js 16** (App Router, React 19) sobre **Supabase**
para un estudio de tatuaje ficticio.

| Carpeta | Qué es | Puerto |
|---|---|---|
| `apps/web` | Web pública: portada, catálogo flash, reserva y cuenta de cliente | 3000 |
| `apps/crm` | Panel privado del estudio: citas, clientes, agenda, facturación, informes, RRHH | 3001 |
| `packages/compartido` | Código común: identidad, tipos, clientes de Supabase, formularios | — |
| `supabase/migrations` | Migraciones SQL | — |

## Requisitos

- Node.js 20 o superior
- Un proyecto de Supabase

## Puesta en marcha

```bash
npm install

# Variables de entorno (rellenar con los datos del proyecto de Supabase)
cp apps/web/.env.example apps/web/.env.local
cp apps/crm/.env.example apps/crm/.env.local

npm run dev        # web  → http://localhost:3000
npm run dev:crm    # CRM  → http://localhost:3001
```

### Variables de entorno

| Variable | Uso |
|---|---|
| `NEXT_PUBLIC_SUPABASE_URL` | URL del proyecto de Supabase |
| `NEXT_PUBLIC_SUPABASE_PUBLISHABLE_KEY` | Clave pública (publishable) de Supabase |
| `SECRETO_HUELLA` | Cadena aleatoria para anonimizar la IP en la web |
| `NEXT_PUBLIC_URL_CRM` / `NEXT_PUBLIC_URL_WEB` | URL de la otra aplicación, para los enlaces entre ambas |

## Scripts

```bash
npm run build   # compila web y CRM para producción
npm run lint    # ESLint en las dos apps
```

Más detalle sobre decisiones y estructura en [`CONTEXT.md`](CONTEXT.md).
